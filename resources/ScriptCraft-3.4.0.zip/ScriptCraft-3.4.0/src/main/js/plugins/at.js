// ensure that the at world-load event handlers are
// registered early in server startup
require('at');
// nothing more needed.
